.render_docx = function(publication, config) {
  .render_pandoc_output(
    publication = publication,
    config = config,
    extension = "docx",
    options = list(
      to = "docx",
      args = .pandoc_profile_args(publication, config)
    )
  )
}

.render_odt = function(publication, config) {
  .render_pandoc_output(
    publication = publication,
    config = config,
    extension = "odt",
    options = list(
      to = "odt",
      args = .pandoc_profile_args(publication, config)
    )
  )
}

.pandoc_profile_args = function(publication, config) {
  section = .yaml_section(config$quarto, "pandoc")

  if (!length(section)) {
    return(character())
  }

  if (is.null(names(section)) || any(!nzchar(names(section)))) {
    stop(
      sprintf(
        "Pandoc configuration in '_quarto-%s.yml' must be a named mapping.",
        config$profile
      ),
      call. = FALSE
    )
  }

  args = character()

  reserved = c("from", "to", "output", "resource-path")
  invalid = intersect(names(section), reserved)

  if (length(invalid)) {
    stop(
      sprintf(
        "Pandoc option%s %s in '_quarto-%s.yml' %s managed by iasi-quarto and cannot be configured under 'pandoc'.",
        if (length(invalid) == 1L) "" else "s",
        paste(sprintf("'%s'", invalid), collapse = ", "),
        config$profile,
        if (length(invalid) == 1L) "is" else "are"
      ),
      call. = FALSE
    )
  }

  for (name in names(section)) {
    value = section[[name]]

    if (identical(name, "args")) {
      args = c(args, .pandoc_explicit_args(value, config$profile))
      next
    }

    args = c(
      args,
      .pandoc_option_args(
        name = name,
        value = value,
        project_path = publication$path,
        profile = config$profile
      )
    )
  }

  args
}

.pandoc_option_args = function(name, value, project_path, profile) {
  option = paste0("--", name)

  if (is.logical(value)) {
    if (length(value) != 1L || is.na(value)) {
      stop(
        sprintf(
          "Pandoc option '%s' in '_quarto-%s.yml' must contain one logical value.",
          name,
          profile
        ),
        call. = FALSE
      )
    }

    if (isTRUE(value)) option else character()
  } else {
    values = .pandoc_option_values(value, name, profile)

    if (identical(name, "reference-doc")) {
      values = vapply(
        values,
        .resolve_pandoc_project_file,
        character(1),
        project_path = project_path,
        option = name,
        profile = profile
      )
    }

    unlist(
      lapply(
        values,
        function(value) c(option, shQuote(value))
      ),
      use.names = FALSE
    )
  }
}

.pandoc_option_values = function(value, name, profile) {
  if (is.null(value)) {
    return(character())
  }

  if (is.list(value)) {
    value = unlist(value, recursive = FALSE, use.names = FALSE)
  }

  if (!is.atomic(value) || !length(value) || anyNA(value)) {
    stop(
      sprintf(
        "Pandoc option '%s' in '_quarto-%s.yml' must contain a scalar or a list of scalar values.",
        name,
        profile
      ),
      call. = FALSE
    )
  }

  values = as.character(value)

  if (any(!nzchar(values))) {
    stop(
      sprintf(
        "Pandoc option '%s' in '_quarto-%s.yml' contains an empty value.",
        name,
        profile
      ),
      call. = FALSE
    )
  }

  values
}

.pandoc_explicit_args = function(value, profile) {
  values = .pandoc_option_values(value, "args", profile)

  if (!length(values)) {
    return(character())
  }

  values
}

.resolve_pandoc_project_file = function(value,
                                         project_path,
                                         option,
                                         profile) {
  path = if (.is_absolute_path(value)) {
    value
  } else {
    file.path(project_path, value)
  }

  if (!file.exists(path)) {
    stop(
      sprintf(
        "Pandoc option '%s' in '_quarto-%s.yml' references missing file '%s'.",
        option,
        profile,
        value
      ),
      call. = FALSE
    )
  }

  normalizePath(
    path,
    winslash = "/",
    mustWork = TRUE
  )
}

.render_single = function(publication, config) {
  if (!identical(publication$type, "book")) {
    stop("Single renderer requires a Quarto book publication.", call. = FALSE)
  }

  .render_pandoc_output(
    publication = publication,
    config = config,
    extension = "html",
    options = list(
      to = "html5",
      standalone = TRUE,
      embed_resources = TRUE,
      title = .single_title(publication$path),
      toc = .single_toc(publication$path)
    )
  )
}

.render_pandoc_output = function(publication,
                                  config,
                                  extension,
                                  options = list()) {
  if (!identical(publication$type, "book")) {
    stop("Pandoc renderer requires a Quarto book publication.", call. = FALSE)
  }

  if (!length(publication$chapters)) {
    stop("Pandoc renderer requires at least one book chapter.", call. = FALSE)
  }

  pandoc_path = config$pandoc$output_path

  if (is.null(pandoc_path) || !dir.exists(pandoc_path)) {
    stop(
      sprintf(
        "Pandoc renderer requires the prepared Pandoc input directory%s.",
        if (is.null(pandoc_path)) "" else sprintf(" '%s'", pandoc_path)
      ),
      call. = FALSE
    )
  }

  inputs = .pandoc_html_inputs(
    publication,
    pandoc_path
  )

  output_path = config$output_path

  if (is.null(output_path)) {
    output_path = publication$path
  }

  dir.create(
    output_path,
    recursive = TRUE,
    showWarnings = FALSE
  )

  output = file.path(
    output_path,
    .profile_output_file(
      publication$path,
      profile = config$profile,
      extension = extension
    )
  )

  filter = .pandoc_main_filter()
  on.exit(unlink(filter, force = TRUE), add = TRUE)

  .pandoc(
    inputs = inputs,
    output = output,
    resource_path = .pandoc_resource_path(inputs, pandoc_path),
    filter = filter,
    options = options
  )

  if (!file.exists(output)) {
    stop(
      sprintf(
        "Pandoc renderer did not create expected output file '%s'.",
        output
      ),
      call. = FALSE
    )
  }

  publication$rendered = TRUE
  publication$profiles = unique(
    c(publication$profiles, config$profile)
  )

  publication
}

.profile_output_file = function(path, profile, extension) {
  quarto = .read_yaml_file(
    file.path(path, "_quarto.yml")
  )

  profile_quarto = .read_yaml_file(
    file.path(path, sprintf("_quarto-%s.yml", profile))
  )

  candidates = list(
    .yaml_field(
      .yaml_section(profile_quarto, "book"),
      "output-file"
    ),
    .yaml_field(
      .yaml_section(quarto, "book"),
      "output-file"
    ),
    basename(path)
  )

  output = basename(path)

  for (candidate in candidates) {
    if (
      is.character(candidate) &&
        length(candidate) == 1L &&
        !is.na(candidate) &&
        nzchar(candidate)
    ) {
      output = candidate
      break
    }
  }

  output = sub(
    sprintf("\\.%s$", extension),
    "",
    output,
    ignore.case = TRUE
  )

  paste0(output, ".", extension)
}

.pandoc_html_inputs = function(publication, html_path) {
  relative = paste0(
    tools::file_path_sans_ext(publication$chapters),
    ".html"
  )

  inputs = file.path(
    html_path,
    relative
  )

  missing = inputs[!file.exists(inputs)]

  if (length(missing)) {
    stop(
      sprintf(
        "Pandoc renderer could not find prepared HTML page%s: %s.",
        if (length(missing) == 1L) "" else "s",
        paste(
          sprintf("'%s'", missing),
          collapse = ", "
        )
      ),
      call. = FALSE
    )
  }

  normalizePath(
    inputs,
    winslash = "/",
    mustWork = TRUE
  )
}

.pandoc_resource_path = function(inputs, pandoc_path) {
  paths = unique(
    c(
      normalizePath(
        pandoc_path,
        winslash = "/",
        mustWork = TRUE
      ),
      dirname(inputs)
    )
  )

  paste(
    paths,
    collapse = .Platform$path.sep
  )
}

.pandoc_main_filter = function() {
  path = tempfile(
    "iasi-pandoc-",
    fileext = ".lua"
  )

  writeLines(
    c(
      "local function collect_main(blocks, output)",
      "  for _, block in ipairs(blocks) do",
      "    if block.t == 'Div' then",
      "      local role = block.attributes['role']",
      "      if block.identifier == 'quarto-document-content' or role == 'main' then",
      "        output:extend(block.content)",
      "      else",
      "        collect_main(block.content, output)",
      "      end",
      "    end",
      "  end",
      "end",
      "",
      "function Pandoc(doc)",
      "  local content = pandoc.List()",
      "  collect_main(doc.blocks, content)",
      "",
      "  if #content > 0 then",
      "    doc.blocks = content",
      "  end",
      "",
      "  return doc",
      "end"
    ),
    path,
    useBytes = TRUE
  )

  path
}

.pandoc = function(inputs,
                    output,
                    resource_path,
                    filter,
                    options = list()) {
  pandoc = Sys.which("pandoc")

  if (!nzchar(pandoc)) {
    stop(
      "Pandoc renderer requires Pandoc, but 'pandoc' was not found in PATH.",
      call. = FALSE
    )
  }

  args = c(
    vapply(inputs, shQuote, character(1)),
    "--from=html"
  )

  to = options$to
  if (
    is.character(to) &&
      length(to) == 1L &&
      !is.na(to) &&
      nzchar(to)
  ) {
    args = c(args, sprintf("--to=%s", to))
  }

  if (isTRUE(options$standalone)) {
    args = c(args, "--standalone")
  }

  if (isTRUE(options$embed_resources)) {
    args = c(args, "--embed-resources")
  }

  args = c(
    args,
    "--lua-filter",
    shQuote(filter),
    "--resource-path",
    shQuote(resource_path)
  )

  title = options$title
  if (
    is.character(title) &&
      length(title) == 1L &&
      !is.na(title) &&
      nzchar(title)
  ) {
    args = c(
      args,
      "--metadata",
      shQuote(sprintf("pagetitle=%s", title))
    )
  }

  if (isTRUE(options$toc)) {
    args = c(args, "--toc")
  }

  extra = options$args
  if (!is.null(extra)) {
    args = c(args, as.character(extra))
  }

  args = c(
    args,
    "--output",
    shQuote(output)
  )

  command = paste(
    c(shQuote(pandoc), args),
    collapse = " "
  )

  message(sprintf("Pandoc command: %s", command))

  status = system2(
    pandoc,
    args
  )

  if (!identical(status, 0L)) {
    stop(
      sprintf(
        "Pandoc rendering failed with status %s.",
        status
      ),
      call. = FALSE
    )
  }

  invisible(TRUE)
}

.single_title = function(path) {
  quarto = .read_yaml_file(
    file.path(path, "_quarto.yml")
  )

  title = .yaml_field(
    .yaml_section(quarto, "book"),
    "title"
  )

  if (
    is.character(title) &&
      length(title) == 1L &&
      !is.na(title) &&
      nzchar(title)
  ) {
    return(title)
  }

  basename(path)
}

.single_toc = function(path) {
  profile = .read_yaml_file(
    file.path(path, "_quarto-single.yml")
  )

  format = .yaml_section(profile, "format")
  html = .yaml_section(format, "html")

  isTRUE(
    .yaml_field(html, "toc")
  )
}
