
# Create the mutable execution context used by every public action.
.new_context = function(...) {
  context = list2env(list(...), parent = emptyenv())
  context$rc = .IASI$status$OK
  context
}


# Accumulate one return-code bit or mask in the execution context.
.rc_add = function(context, rc) {
  context$rc = bitwOr(as.integer(context$rc), as.integer(rc))
  invisible(context$rc)
}


.attention = function(context, ...) {
  message("ATTENTION: ", ...)
  .rc_add(context, .IASI$status$ATTENTION)
  invisible(context$rc)
}


.prepare_context = function(context) {
  context$path = normalizePath(context$path, winslash = "/", mustWork = TRUE)
  context$plan = .discover(context)
  context$projects = .select_projects(context)
  context$current = length(context$projects) == 1L && identical(context$projects[[1L]]$path, context$path)
  context
}


.select_projects = function(context) {
  if (!length(context$plan)) {
    .rc_add(context, .IASI$status$NOTHING_TO_DO)
    return(list())
  }

  projects = lapply(context$plan, function(path) .read_iasi_project(path, context))
  projects = Filter(Negate(is.null), projects)

  selected = Filter(
    function(project) !identical(project$config$iasi$type, .IASI$types$repo),
    projects
  )

  if (!length(selected)) .rc_add(context, .IASI$status$NOTHING_TO_DO)

  selected
}


.read_iasi_project = function(path, context) {
  config_file = .iasi_file(path, context = context)

  if (is.null(config_file)) {
    .attention(context, "Missing iasi.toml in: ", path)
    return(NULL)
  }

  iasi = .read_config(config_file)
  type = iasi$type

  if (is.null(type) || !is.character(type) || length(type) != 1L || is.na(type) || !nzchar(type)) {
    .attention(context, "Missing project type in: ", config_file)
    return(NULL)
  }

  valid = unname(unlist(.IASI$types, use.names = FALSE))

  if (!type %in% valid) {
    .attention(context, "Invalid project type '", type, "' in: ", config_file)
    return(NULL)
  }

  project = list(
    name = basename(path),
    path = normalizePath(path, winslash = "/", mustWork = TRUE),
    config_file = normalizePath(config_file, winslash = "/", mustWork = TRUE),
    config = list(
      iasi = iasi,
      quarto = .read_quarto_config(path)
    )
  )

  class(project) = c("iasi_project", "list")
  project
}


.prepare_project_config = function(project) {
  project$config$iasi = .resolve_config(project)
  project
}


.resolve_config = function(project) {
  config = project$config$iasi
  path = dirname(project$path)

  repeat {
    inherited = .read_optional_iasi(path)

    if (!is.null(inherited)) config = .merge_missing(config, inherited)

    parent = dirname(path)
    if (identical(parent, path)) break
    path = parent
  }

  if (is.null(config$paths)) config$paths = list()
  if (is.null(config$paths$publish)) config$paths$publish = .IASI$dirs$publish
  if (is.null(config$paths$release)) config$paths$release = .IASI$dirs$release

  config
}


.merge_missing = function(target, source) {
  if (!is.list(source)) return(target)

  for (name in names(source)) {
    if (is.null(target[[name]])) {
      target[[name]] = source[[name]]
    } else if (is.list(target[[name]]) && is.list(source[[name]])) {
      target[[name]] = .merge_missing(target[[name]], source[[name]])
    }
  }

  target
}


.read_optional_iasi = function(path) {
  file = .iasi_file(path, warn_legacy = FALSE)
  if (is.null(file)) return(NULL)
  .read_config(file)
}


.iasi_file = function(path, context = NULL, warn_legacy = TRUE) {
  canonical = file.path(path, .IASI$files$iasi)
  legacy = file.path(path, .IASI$files$legacy_iasi)
  existing_legacy = legacy[file.exists(legacy)]

  if (warn_legacy && file.exists(canonical) && length(existing_legacy)) {
    if (is.null(context)) {
      message(
        "ATTENTION: Multiple IASI configuration files found in: ",
        path,
        ". Using iasi.toml; legacy files: ",
        paste(basename(existing_legacy), collapse = ", ")
      )
    } else {
      .attention(
        context,
        "Multiple IASI configuration files found in: ",
        path,
        ". Using iasi.toml; legacy files: ",
        paste(basename(existing_legacy), collapse = ", ")
      )
    }
  }

  if (!file.exists(canonical)) return(NULL)
  canonical
}


.read_config = function(path) {
  config = tryCatch(
    RcppTOML::parseTOML(path),
    error = function(error) {
      message("Invalid IASI TOML configuration: ", path, ": ", conditionMessage(error))
      stop(error)
    }
  )

  if (is.null(config)) config = list()

  if (!is.list(config)) {
    message("IASI configuration must be a TOML table: ", path)
    stop("Invalid IASI configuration.", call. = FALSE)
  }

  unclass(config)
}


.read_quarto_config = function(path) {
  base_file = file.path(path, .IASI$files$quarto)
  base = if (file.exists(base_file)) .read_yaml_file(base_file) else NULL

  profile_files = list.files(
    path,
    pattern = "^_quarto-.+\\.ya?ml$",
    full.names = TRUE,
    recursive = FALSE,
    ignore.case = TRUE
  )

  profiles = lapply(profile_files, .read_yaml_file)

  if (length(profile_files)) {
    names(profiles) = sub(
      "^_quarto-(.+)\\.ya?ml$",
      "\\1",
      basename(profile_files),
      ignore.case = TRUE
    )
  }

  list(
    base = base,
    profiles = profiles
  )
}
