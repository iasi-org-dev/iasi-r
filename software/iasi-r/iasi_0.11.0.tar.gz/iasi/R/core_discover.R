
.discover = function(context) {
  root = normalizePath(context$path, winslash = "/", mustWork = TRUE)

  directories = c(
    root,
    list.dirs(
      root,
      recursive = TRUE,
      full.names = TRUE
    )
  )

  directories = unique(
    normalizePath(
      directories,
      winslash = "/",
      mustWork = TRUE
    )
  )

  relative = vapply(
    directories,
    function(path) {
      if (identical(tolower(path), tolower(root))) {
        return(".")
      }

      substring(path, nchar(root) + 2L)
    },
    character(1)
  )

  excluded = grepl(
    "(^|/)(\\.git|tests|\\.Rcheck|\\.Rproj\\.user|\\.quarto|_freeze|_generated|_outputs)(/|$)",
    relative,
    ignore.case = TRUE
  )

  directories = directories[!excluded]

  discovery_files = c(
    .IASI$files$iasi,
    .IASI$files$legacy_iasi,
    .IASI$files$quarto
  )

  projects = directories[
    vapply(
      directories,
      function(path) {
        candidates = file.path(path, discovery_files)
        any(file.exists(candidates))
      },
      logical(1)
    )
  ]

  sort(unique(projects))
}
